﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePizza : MonoBehaviour {

    public float rotMaxX = 45f, rotMaxY = 45f;
    Vector2 screenBounds;

	// Use this for initialization
	void Start () {
        screenBounds = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, Screen.height));

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }
	
	// Update is called once per frame
	void Update () {

        Vector2 mousePos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);

        float ratioX = -((mousePos.x / screenBounds.x) * rotMaxX) + (rotMaxX /2) + 3f;
        float ratioY = ((mousePos.y / screenBounds.y) * rotMaxY) - (rotMaxY/2) - 1;

        Quaternion rotation = Quaternion.Euler(ratioY + 90, ratioX, 180);
        gameObject.transform.rotation = rotation;
	}
}
