﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RocketShoot : MonoBehaviour {

    public GameObject player;
    public GameObject playerCamera;
    public GameObject rocketPrefab;
    public GameObject launcher;
    public float reloadTime;
    float previousTime = 0;
    bool onCooldown;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        CheckInput();
	}

    void CheckInput()
    {
        if(onCooldown && Time.fixedTime - previousTime >= reloadTime)
        {
            onCooldown = false;
        }
        if (Input.GetMouseButtonDown(0) && !onCooldown)
        {
            Fire();
        }
        if (Input.GetKeyDown(KeyCode.F))
        {
            gameObject.GetComponent<HookShoot>().enabled = true;
            enabled = false;
        }
    }

    void Fire()
    {
        onCooldown = true;
        previousTime = Time.fixedTime;
    }
}
