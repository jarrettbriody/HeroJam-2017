﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DontDest : MonoBehaviour {

    public int availableLevels = 1;
    public List<GameObject> levels;
    //public GameObject ButtonParent;

    // Use this for initialization
    void Start () {
        //GameObject.DontDestroyOnLoad(gameObject);
        if(PlayerPrefs.GetInt("availableLevel") != 0)
        {
            availableLevels = PlayerPrefs.GetInt("availableLevel");
        }

        PlayerPrefs.SetInt("availableLevel", availableLevels);

        /* for (int i = 0; i < gameObject.transform.childCount; i++)
         {
             levels.Add(ButtonParent.transform.GetChild(i).gameObject);

         }*/
    }
	
	// Update is called once per frame
	void Update () {
		if(availableLevels > 1)
        {
            for (int i = 0; i < availableLevels; i++)
            {
                levels[i].GetComponent<Selectable>().interactable = true;
            }
        }
	}
}
