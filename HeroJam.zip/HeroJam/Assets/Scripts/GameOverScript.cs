﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOverScript : MonoBehaviour {

    public GameObject mainMenuPanel;
    public GameObject gameOverPanel;

    string gameOver;

	// Use this for initialization
	void Start () {

        gameOver = PlayerPrefs.GetString("GameOver");

        if (gameOver == "true")
        {
            mainMenuPanel.SetActive(false);
            gameOverPanel.SetActive(true);
        }
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
