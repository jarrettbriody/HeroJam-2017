﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {

    // attributes
    public Vector3 direction = new Vector3(0, 0, 0);
    public float speed = 1f, maxSpeed = 10f, maxMovement = 0;
    private Vector3 accereration;
    public Vector3 velocity, total;

    // Use this for initialization
    void Start () {
        accereration = new Vector3();
        velocity = new Vector3();
    }
	
	// Update is called once per frame
	void Update () {
        accereration = direction * speed;

        velocity += accereration;
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);

        transform.position += velocity;
        total += velocity;

        if (maxMovement != 0 && total.magnitude > maxMovement)
        {
            total = Vector3.zero;
            direction = -direction;
        }
	}

    public void Reset()
    {
        total = Vector3.zero;
        velocity = Vector3.zero;
    }
}
