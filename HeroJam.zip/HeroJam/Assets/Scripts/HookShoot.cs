﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class HookShoot : MonoBehaviour
{

    public GameObject launcher, ropeRef, hookRef, launchPoint, playerCamera, crosshair, player;
    public ParticleSystem particles;
    PlayerScript playerScript;
    GameObject rope, hook;
    collideScript hookScript;
    Vector3 ropePos, hookPos;
    Vector3 ropeScale;
    Vector3 hookVelocity, velocity;
    public float ropeMax = 15;
    public float hookSpeed = 0.5f;
    public bool hookOut, hooked;
    public float minDistance = 1.5f;
    public float stopDistance = 1;
    public Texture2D crosshairText, crosshairText_close, crosshairText_far, crosshairText_wrong;
    public float crosshairScale = 1;

    public RigidbodyFirstPersonController controller;
    public float momentum, speed = 15f, step;
    Rigidbody playerRB;
    bool lookingAtObj, objClose, objWrong;
    public int numOfShots;

    GameObject hookCaught;
    Vector3 hookCaughtOffset;
    Quaternion hookCaughtRot;

    // Use this for initialization
    void Start()
    {
        particles.Stop();
        hookOut = false;
        velocity = Vector3.zero;
        playerScript = player.GetComponent<PlayerScript>();
        playerRB = player.GetComponent<Rigidbody>();

        //setup player settings
        ropeMax = 50;
        minDistance = 1.5f;

        hookSpeed = 2;
        stopDistance = 1;
        speed = 15;
        numOfShots = 0;
    }

    private void OnGUI()
    {
        Texture2D toUse = crosshairText;
        if (lookingAtObj && !objWrong)
        {
            if (objClose)
            {
                toUse = crosshairText_close;
            }
            else
            {
                toUse = crosshairText_far;
            }
        }
        else if (objWrong)
        {
            toUse = crosshairText_wrong;
        }
        GUI.DrawTexture(new Rect((Screen.width - (crosshairText.width * crosshairScale)) / 2, (Screen.height - (crosshairText.height * crosshairScale)) / 2, crosshairText.width * crosshairScale, crosshairText.height * crosshairScale), toUse);
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetMouseButtonDown(0) && !hookOut)
        {
            HookFire();
            hookOut = true;
            numOfShots++;
        }
        if (Input.GetMouseButtonDown(1) && hooked)
        {
            hooked = false;
            playerRB.isKinematic = false;
            playerRB.velocity = player.transform.forward * momentum;
            DeleteGrapple();

            particles.time = playerRB.velocity.magnitude / 20;
            particles.Play();
        }
        if (hooked)
        {
            playerRB.isKinematic = true;
            momentum += Time.deltaTime * speed;
            step = momentum * Time.deltaTime;
            player.transform.position = Vector3.MoveTowards(player.transform.position, hook.transform.position, step);
        }
        else if (!hooked)
        {
            playerRB.isKinematic = false;
            if (momentum >= 20)
            {
                momentum -= Time.deltaTime * speed;
                step = 0;
            }
        }

        if (hookOut)
        {
            Vector3 distance = hook.transform.position - launchPoint.transform.position;
            UpdateHookPos(distance);
            UpdateRope(distance);

            if (hooked)
            {
                if (distance.magnitude < minDistance)
                {
                    DeleteGrapple();
                }
            }
        }

        if (controller.Grounded && momentum <= 0)
        {
            momentum = 0;
            step = 0;
        }

        TestCrosshair();

    }

    void TestCrosshair()
    {
        Vector3 finalPos = Vector3.zero;

        Vector3 cameraCenter = playerCamera.transform.position;
        Vector3 direction = (crosshair.transform.position - playerCamera.transform.position).normalized;
        
        RaycastHit hitInfo;
        if (Physics.Raycast(cameraCenter, direction, out hitInfo))
        {
            lookingAtObj = true;
            if (hitInfo.transform.tag == "Grapple" || hitInfo.transform.tag == "GrappleMoving")
            {
                objWrong = false;
                if ((hitInfo.point - launcher.transform.position).magnitude < ropeMax)
                {
                    objClose = true;
                }
                else
                {
                    objClose = false;
                }
            }
            else
            {
                objWrong = true;
            }
        }
        else
        {
            lookingAtObj = false;
            objWrong = false;
        }
    }

    Vector3 TestHookFire()
    {
        Vector3 finalPos = Vector3.zero;

        Vector3 cameraCenter = playerCamera.transform.position;
        Vector3 direction = (crosshair.transform.position - playerCamera.transform.position).normalized;

        finalPos = cameraCenter + direction * ropeMax;
        RaycastHit hitInfo;
        if (Physics.Raycast(cameraCenter, direction, out hitInfo, ropeMax))
        {
            finalPos = hitInfo.point;
        }
        return finalPos;
    }

    void HookFire()
    {

        Vector3 firePos = TestHookFire();

        hook = Instantiate(hookRef);
        hookScript = hook.GetComponent<collideScript>();
        rope = Instantiate(ropeRef);

        SphereCollider hookCollider = hook.GetComponent<SphereCollider>();
        BoxCollider launcherCollider = gameObject.GetComponent<BoxCollider>();

        //set-up velocity of hook
        Vector3 direction = firePos - launchPoint.transform.position;
        direction = direction.normalized;
        hookVelocity = direction * hookSpeed;

        //set-up hook positons
        hook.transform.position = launchPoint.transform.position;
        hook.transform.rotation = Quaternion.LookRotation(direction);
        //set-up rope positions
        rope.transform.position = launchPoint.transform.position;
        rope.transform.rotation = Quaternion.LookRotation(direction);

    }

    void UpdateHookPos(Vector3 distance)
    {
        if (!hooked)
        {
            int iterations = 100;
            int num = iterations;
            

            Vector3 deltaVelocity = hookVelocity;

            if (distance.magnitude >= ropeMax)
            {
                DeleteGrapple();
                hook = null;
                num = 0;
            }
            else if (distance.magnitude >= (ropeMax * 0.2))
            {
                deltaVelocity = hookVelocity * ((1.0f - (distance.magnitude / ropeMax)) + 0.5f);
            }

            if (hook == null)
            {
                return;
            }

            hook.transform.position += deltaVelocity;
            num--;
        }
        
         // test collision
        if (hookScript.isCollision && !hooked)
        {
            if (hookScript.grappleCollision)
            {
                if (momentum < 20)
                {
                    momentum = 20;
                }
                hooked = true;
                playerRB.isKinematic = true;

                if (hookScript.movingObj)
                {
                    hookCaught = hookScript.hitObj;
                    hook.transform.parent = hookCaught.transform;
                }
                else
                {
                    hookCaught = null;
                }
            }
            else
            {
                DeleteGrapple();
            }
        }
    }

    void UpdateRope(Vector3 distance)
    {
        if (hook == null)
        {
            return;
        }
        rope.transform.localScale = new Vector3(1, 1, distance.magnitude * 19.3f);

        Vector3 direction = hook.transform.position - launchPoint.transform.position;
        rope.transform.rotation = Quaternion.LookRotation(direction);
        rope.transform.position = launchPoint.transform.position;

    }

    void DeleteGrapple()
    {
        Destroy(hook);
        hookScript = null;
        Destroy(rope);
        hookOut = false;
        hooked = false;
        velocity = Vector3.zero;
    }


}