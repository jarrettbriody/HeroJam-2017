﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WinScore : MonoBehaviour {
    public Text score;
    public Text time;
    // Use this for initialization
    void Start () {
        float score1 = PlayerPrefs.GetFloat("lastScore");
        float time1 = PlayerPrefs.GetFloat("lastTime");

        score.text += score1;
        time.text += time1;


	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
