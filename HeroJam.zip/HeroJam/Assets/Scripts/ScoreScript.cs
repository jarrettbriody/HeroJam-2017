﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreScript : MonoBehaviour {

    public string name = "";
    float time;
    float bestTime;

    int score;
    int gameScore;

    bool complete = false;

	// Use this for initialization
	void Start () {
        gameScore = PlayerPrefs.GetInt(name);
        time = Time.timeSinceLevelLoad;
        bestTime = PlayerPrefs.GetFloat(name);
	}
	
	// Update is called once per frame
	void Update () {

        time = Time.timeSinceLevelLoad;

        if (complete)
        {
            if (score > PlayerPrefs.GetInt(name))
            {
                PlayerPrefs.SetInt(name, score);
            }
            complete = !complete;
        }

    }

    public float ReturnTime()
    {
        return time;
    }

    void OnGUI()
    {
        int minutes = (int)(time / 60);
        int seconds = (int)(time % 60);
        float miliseconds = ((int)(time)) / time;
        GUI.Label(new Rect(10, 10, 100, 90), "Time: " + minutes + ":" + seconds + ":" + miliseconds);
    }
}
