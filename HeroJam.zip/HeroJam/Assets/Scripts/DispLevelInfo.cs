﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DispLevelInfo : MonoBehaviour {

    public List<GameObject> levels;
    //public PlayerPrefs ourPrefs; 
	// Use this for initialization
	void Start () {
        /*for(int i = 0; i < gameObject.transform.childCount; i++)
        {
            levels.Add(gameObject.transform.GetChild(i).gameObject);
        }*/




        //wright the scores and times
        for (int i = 0; i < levels.Count; i++)
        {
            string ScoreTag = "0";
            string TimeTag="0";
            if(i == 0)
            {
                ScoreTag = "City_score";
                TimeTag = "City_time";

                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if(i == 1)
            {
                ScoreTag = "Rural_score";
                TimeTag = "Rural_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if (i == 2)
            {
                ScoreTag = "Forest_score";
                TimeTag = "Forest_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if (i == 3)
            {
                ScoreTag = "Rocks_score";
                TimeTag = "Rocks_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if (i == 4)
            {
                ScoreTag = "Mirror_score";
                TimeTag = "Mirror_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if (i == 5)
            {
                ScoreTag = "Sky_score";
                TimeTag = "Sky_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if (i == 6)
            {
                ScoreTag = "Construction_score";
                TimeTag = "Construction_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if (i == 7)
            {
                ScoreTag = "Laser_score";
                TimeTag = "Laser_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if (i == 8)
            {
                ScoreTag = "Blimps_score";
                TimeTag = "Blimps_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }
            else if (i == 9)
            {
                ScoreTag = "Canyon_score";
                TimeTag = "Canyon_time";
                levels[i].transform.GetChild(1).GetComponent<Text>().text += (int)PlayerPrefs.GetFloat(ScoreTag);
                levels[i].transform.GetChild(2).GetComponent<Text>().text += PlayerPrefs.GetFloat(TimeTag);
            }






        }

    }
	
	// Update is called once per frame
	void Update () {
        
	}
}
