﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityStandardAssets.Characters.FirstPerson;


public class LevelScript : MonoBehaviour {

    // attributes
    public GameObject playerStart, playerPrefab;
    public float ceiling, floor;
    private GameObject player;
    private int deaths;
    private RigidbodyFirstPersonController playerController;
    public Font myFont;
   // public GameObject levTrac; 

    //score stuff
    public string name = "";
    float time;
    float bestTime;

    // to reset gameobjects
    public GameObject[] movables;
    private List<Vector3> startPositions = new List<Vector3>();
    private List<Quaternion> startRotations = new List<Quaternion>();

    // Use this for initialization
    void Start () {
        // create the player
        player = Instantiate(playerPrefab, playerStart.transform);

        // ints 
        deaths = 0;

        //List<GameObject> li = levTrac.GetComponent<DontDest>().levels;

        playerController = player.GetComponent<RigidbodyFirstPersonController>();

        //score stuff
        time = Time.timeSinceLevelLoad;
        bestTime = PlayerPrefs.GetFloat(name);

        //levTrac = GameObject.Find("leveltracker");

        movables = GameObject.FindGameObjectsWithTag("GrappleMoving");

        startPositions = new List<Vector3>();
        startRotations = new List<Quaternion>();
        for (int i = 0; i < movables.Length; i++)
        {
            startPositions.Add(movables[i].transform.position);
            startRotations.Add(movables[i].transform.rotation);
        }
    }
	
	// Update is called once per frame
	void Update () {
        
        //score
        time = Time.timeSinceLevelLoad;

        if (player.transform.position.y > ceiling || player.transform.position.y < floor)
        {
            Restart();
        }

        if (playerController == null)
        {
            playerController = player.GetComponent<RigidbodyFirstPersonController>();
        }
        Collision collision = playerController.col;
        try
        {
            if (collision.gameObject.tag == "GoalPole")
            {
                Win();
            }
            if (collision.gameObject.tag == "laser")
            {
                Restart();
            }
        }
        catch (Exception e)
        {

        }
    }

    void Restart()
    {
        Destroy(player);
        player = Instantiate(playerPrefab, playerStart.transform);
        deaths++;
        playerController = player.GetComponent<RigidbodyFirstPersonController>();
        Destroy(GameObject.Find("Hook(Clone)"));
        Destroy(GameObject.Find("Rope(Clone)"));
        ResetMovables();
    }

    void Win()
    {
        bool newBestTime = false, newBestScore = false;

        float bestTime = PlayerPrefs.GetFloat(name + "_time");

        if (time < bestTime || bestTime == 0)
        {
            newBestScore = true;
            PlayerPrefs.SetFloat(name + "_time", time);
        }
        
        float score = 0;
        
        GameObject launcher = GameObject.Find("Launcher");
        int numOfShots = launcher.GetComponent<HookShoot>().numOfShots;
        
        float maxTimeScore = 10000;
        score = maxTimeScore - (time * 20);
        
        score -= (numOfShots * 50);
        
        float bestScore = PlayerPrefs.GetFloat(name + "_score");
        if (score > bestScore)
        {
            newBestScore = true;
            PlayerPrefs.SetFloat(name + "_score", score);
        }
        /*
        //if number of available levels isnt too high increase the number of available levels
        int length = levTrac.GetComponent<DontDest>().levels.Count;
        if (levTrac.GetComponent<DontDest>().availableLevels < length)
        {
            levTrac.GetComponent<DontDest>().availableLevels++;
        }
        */

        int avLev = PlayerPrefs.GetInt("availableLevel");
        Debug.Log(avLev);
        if(avLev < 10)
        {
            avLev++;
        }
        Debug.Log(avLev);
        PlayerPrefs.SetInt("availableLevel", avLev);

        PlayerPrefs.SetFloat("lastScore", score);
        PlayerPrefs.SetFloat("lastTime", time);

        PlayerPrefs.SetString("GameOver", "true");

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        SceneManager.LoadScene(0);
    }

    void OnGUI()
    {
        GUIStyle style = new GUIStyle(GUI.skin.label);
        style.fontSize = 50;
        style.font = myFont;


        time = Mathf.Round(time * 100f) / 100f;
        GUI.Label(new Rect(10, 10, 500, 100), "Time: "+time, style);
    }

    void ResetMovables()
    {
        for (int i = 0; i < movables.Length; i++)
        {
            movables[i].transform.position = startPositions[i];
            movables[i].transform.rotation = startRotations[i];
            if (movables[i].GetComponent<Movement>())
                movables[i].GetComponent<Movement>().Reset();
        }
    }
}
