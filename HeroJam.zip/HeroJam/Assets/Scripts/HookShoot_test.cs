﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class HookShoot_test : MonoBehaviour {

    public GameObject launcher, ropeRef, hookRef, launchPoint, playerCamera, crosshair, player;
    PlayerScript playerScript;
    GameObject rope, hook;
    collideScript hookScript;
    Vector3 mainPos, ropePos, hookPos;
    Vector3 ropeScale;
    Vector3 hookVelocity, velocity;
    public float ropeMax = 15;
    public float hookSpeed = 0.5f;
    float ropeLength;
    public bool hookOut, hooked;
    public float reelMax = 1, minDistance = 1.5f;
    public float stopDistance = 1;
    public Texture2D crosshairText;
    public float crosshairScale = 1;

    public RigidbodyFirstPersonController controller;
    public float pullSpeed = 1f, startPullForce = 1f;
    bool startPull = false;
    Rigidbody playerRB;
    public float maxSpeed = 2f;


    // Use this for initialization
    void Start () {
        mainPos = launcher.transform.position;
        hookOut = false;
        startPull = false;
        velocity = Vector3.zero;
        playerScript = player.GetComponent<PlayerScript>();
        playerRB = player.GetComponent<Rigidbody>();
	}

    private void OnGUI()
    {
        GUI.DrawTexture(new Rect((Screen.width - (crosshairText.width * crosshairScale)) / 2, (Screen.height - (crosshairText.height * crosshairScale)) / 2, crosshairText.width * crosshairScale, crosshairText.height * crosshairScale), crosshairText);
    }

    // Update is called once per frame
    void Update () {
		
        if (Input.GetMouseButtonDown(0) && !hookOut)
        {
            HookFire();
            hookOut = true;
            startPull = false;
        }
        if (Input.GetMouseButtonDown(1) && hooked)
        {
            hooked = false;
            DeleteGrapple();
        }
        if (hooked)
        {
            Vector3 direction = (hook.transform.position - player.transform.position).normalized;
            Vector3 force = direction * pullSpeed;

            if (!startPull)
            {
                startPull = true;
                force *= startPullForce;
            }

            velocity += force * Time.deltaTime;
            
        }
        
        if (controller.Grounded && hooked == false)
        {
            velocity = Vector3.zero;
        }
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);
        player.transform.position += velocity;

        if (hookOut)
        {
            Vector3 distance = hook.transform.position - launchPoint.transform.position;
            UpdateHookPos(distance);
            UpdateRope(distance);

            if (hooked)
            {
                if (distance.magnitude < minDistance)
                {
                    DeleteGrapple();
                }
            }
        }
    }

    Vector3 TestHookFire()
    {
        Vector3 finalPos = Vector3.zero;

        Vector3 cameraCenter = playerCamera.transform.position;
        Vector3 direction = (crosshair.transform.position - playerCamera.transform.position).normalized;

        finalPos = cameraCenter + direction * ropeMax;
        RaycastHit hitInfo;
        if (Physics.Raycast(cameraCenter, direction, out hitInfo, ropeMax))
        {
            finalPos = hitInfo.point;
        }
        return finalPos;
    }

    void HookFire()
    {

        Vector3 firePos = TestHookFire();

        hook = Instantiate(hookRef);
        hookScript = hook.GetComponent<collideScript>();
        rope = Instantiate(ropeRef);

        SphereCollider hookCollider = hook.GetComponent<SphereCollider>();
        BoxCollider launcherCollider = gameObject.GetComponent<BoxCollider>();

        //set-up velocity of hook
        Vector3 direction = firePos - launchPoint.transform.position;
        direction = direction.normalized;
        hookVelocity = direction * hookSpeed;

        //set-up hook positons
        hook.transform.position = launchPoint.transform.position;
        hook.transform.rotation = Quaternion.LookRotation(direction);
        //set-up rope positions
        rope.transform.position = launchPoint.transform.position;
        rope.transform.rotation = Quaternion.LookRotation(direction);

    }

    void UpdateHookPos(Vector3 distance)
    {
        if (!hooked)
        {
            int iterations = 100;
            bool deleteGrapple = false;
            int num = iterations;
            do
            {
                // test collision
                if (hookScript.isCollision)
                {
                    if (hookScript.grappleCollision)
                    {
                        hooked = true;
                    }
                    else
                    {
                        deleteGrapple = true;
                        num = 0;
                    }
                }

                Vector3 deltaVelocity = hookVelocity;

                if (distance.magnitude >= ropeMax)
                {
                    DeleteGrapple();
                    num = 0;
                }
                else if (distance.magnitude >= (ropeMax * 0.2))
                {
                    deltaVelocity = hookVelocity * ((1.0f - (distance.magnitude / ropeMax)) + 0.5f);
                }

                hook.transform.position += deltaVelocity / iterations;
                num--;
            } while (num > 0);
            if (deleteGrapple)
            {
                DeleteGrapple();
            }
        }

    }

    void UpdateRope(Vector3 distance)
    {
        rope.transform.localScale = new Vector3(1, 1, distance.magnitude * 19.3f);

        Vector3 direction = hook.transform.position - launchPoint.transform.position;
        rope.transform.rotation = Quaternion.LookRotation(direction);
        rope.transform.position = launchPoint.transform.position;

    }

    void DeleteGrapple()
    {
        Destroy(hook);
        hookScript = null;
        Destroy(rope);
        hookOut = false;
        hooked = false;
    }


}
 