﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collideScript : MonoBehaviour {

    public bool isCollision;
    public bool grappleCollision;
    public bool movingObj;
    public GameObject hitObj;

	// Use this for initialization
	void Start () {
        isCollision = false;
        grappleCollision = false;
        movingObj = false;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Player" || collision.gameObject.tag == "MainCamera")
        {
            return;
        }
        else
        {
            isCollision = true;
            if (collision.gameObject.tag == "Grapple")
            {
                grappleCollision = true;
                movingObj = false;
            }
            else if (collision.gameObject.tag == "GrappleMoving")
            {
                grappleCollision = true;
                movingObj = true;
                hitObj = collision.gameObject;
            }
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        isCollision = false;
        grappleCollision = false;
    }
}
