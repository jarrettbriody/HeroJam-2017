﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {

    // attributes
    public Camera playerCam;
    public GameObject launcher;
    private Rigidbody playerRB;
    private CapsuleCollider playerCol;
    private KeyCode forward, left, right, back, jump, shoot;
    public float speed, maxSpeed, jumpHeight;
    private bool midair;
    private Vector3 acceleration, directionForward, directionRight, velocity, lastPosition;
    public bool drawCrosshair, gravOn;
    public Texture2D crosshair;
    public float crosshairScale = 1f;
    private HookShoot hookScript;

    // Use this for initialization
    void Start () {
        // setting components
        playerRB = GetComponent<Rigidbody>();
        playerCol = GetComponent<CapsuleCollider>();
        hookScript = launcher.GetComponent<HookShoot>();

        // inputs
        forward = KeyCode.W;
        left = KeyCode.A;
        right = KeyCode.D;
        back = KeyCode.S;
        jump = KeyCode.Space;

        // staying upright
        playerRB.freezeRotation = true;

        // floats
        speed = 1f;
        maxSpeed = .1f;
        jumpHeight = 500f;

        // bools
        midair = true;
        drawCrosshair = true;
        gravOn = true;

        // Vector 3s
        acceleration = Vector3.zero;
        velocity = Vector3.zero;
        directionForward = Vector3.forward;
        directionRight = Vector3.right;
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        // setting directions
        directionForward = Quaternion.Euler(0, playerCam.transform.rotation.eulerAngles.y, 0) * Vector3.forward;
        directionRight = Quaternion.Euler(0, playerCam.transform.rotation.eulerAngles.y, 0) * Vector3.right;

        gameObject.transform.position += Movement();

        // Jumping
        if (Input.GetKeyDown(jump) && !midair)
        {
            midair = true;
            playerRB.AddForce(new Vector3(0, jumpHeight, 0));
        }

        // Gravity switch
        if (gravOn)
            playerRB.useGravity = true;

        else
            playerRB.useGravity = false;

        if (!hookScript.hookOut)
            gravOn = true;

        if (Input.GetKeyDown(KeyCode.R))
            Reset();

        if (midair)
            velocity /= 1.005f;
    }

    Vector3 Movement()
    {
        // temporarys
        Vector3 temp1 = Vector3.zero;
        Vector3 temp2 = Vector3.zero;

        if (!midair)
        {
            // Increase or decrease the speed
            if (Input.GetKey(forward))
                temp1 = directionForward * speed;

            else if (Input.GetKey(back))
                temp1 = -directionForward * speed;

            if (Input.GetKey(forward) && Input.GetKey(back))
                temp1 = Vector3.zero;

            if (Input.GetKey(right))
                temp2 = directionRight * speed;

            else if (Input.GetKey(left))
                temp2 = -directionRight * speed;

            if (Input.GetKey(right) && Input.GetKey(left))
                temp2 = Vector3.zero;

            if (!Input.GetKey(forward) && !Input.GetKey(back) && !Input.GetKey(right) && !Input.GetKey(left))
            {
                acceleration = Vector3.zero;
                velocity /= 1.1f;
            }

            // add temps to acceleration
            acceleration = temp1 + temp2;

            // increase the velocity
            velocity += acceleration;

            // clamp the velocity and make sure it cannot go backwards
            velocity = Vector3.ClampMagnitude(velocity, maxSpeed);
        }

        else
        {
            // Increase or decrease the speed
            // Increase or decrease the speed
            if (Input.GetKey(forward))
                temp1 = directionForward * speed;

            else if (Input.GetKey(back))
                temp1 = -directionForward * speed;

            if (Input.GetKey(right))
                temp2 = directionRight * speed;

            else if (Input.GetKey(left))
                temp2 = -directionRight * speed;

            // add temps to acceleration
            acceleration = temp1 + temp2;
            acceleration = Vector3.ClampMagnitude(acceleration, 0.01f);

            // increase the velocity
            velocity += acceleration;
        }

        return Time.deltaTime * velocity * 100f;
    }

    // Collisions
    void OnCollisionEnter(Collision col)
    {
        if (midair && col.gameObject.tag == "Ground")
            midair = false;
    }

    void OnCollisionExit(Collision collision)
    {
        Debug.Log("Working");
        if (collision.gameObject.tag == "Ground")
            midair = true;
    }

    public void ApplyForce(Vector3 force)
    {
        velocity += Time.deltaTime * force;
    }

    public void StopPlayer()
    {
        velocity = Vector3.zero;
    }
    
    private void OnGUI()
    {
        if (drawCrosshair)
        {
            GUI.DrawTexture(new Rect((Screen.width - (crosshair.width * crosshairScale)) / 2, (Screen.height - (crosshair.height * crosshairScale)) / 2, crosshair.width * crosshairScale, crosshair.height * crosshairScale), crosshair);
        }
    }

    public void Reset()
    {
        transform.position = Vector3.zero;
        transform.position = new Vector3(transform.position.x, 5, transform.position.z);
        velocity = Vector3.zero;
        acceleration = Vector3.zero;
        midair = true;
        gravOn = true;
    }
}
