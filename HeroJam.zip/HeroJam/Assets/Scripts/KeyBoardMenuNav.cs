﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class KeyBoardMenuNav : MonoBehaviour {

    public EventSystem eSys;
    public GameObject selectedB;

    private bool bSelected;


	// Use this for initialization
	void Start () {
       
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetAxisRaw("Vertical") != 0 && bSelected == false)
        {
            eSys.SetSelectedGameObject(selectedB);
            bSelected = true;
        }
	}

    private void OnDisable()
    {
        bSelected = false;
    }

}




