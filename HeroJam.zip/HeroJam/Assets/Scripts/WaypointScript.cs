﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaypointScript : MonoBehaviour {

    private GameObject endPole;

	// Use this for initialization
	void Start () {
        endPole = GameObject.Find("GoalPole");
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 arrowPos = gameObject.transform.position;
        Vector3 endPos = endPole.transform.position;

        Vector3 direction = (arrowPos - endPos).normalized;

        Quaternion rotation = Quaternion.LookRotation(direction);
        gameObject.transform.rotation = rotation;
        gameObject.transform.Rotate(new Vector3(0, 90, 0));
	}
}
